# Vue JS authentication

A Pen created on CodePen.io. Original URL: [https://codepen.io/Lewitje/pen/yGwYWY](https://codepen.io/Lewitje/pen/yGwYWY).

A Vue JS login form with success states